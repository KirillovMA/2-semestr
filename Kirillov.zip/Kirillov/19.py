s = input()
a = s.split(" ")
result = a[1]+" "+a[0]
print(result)