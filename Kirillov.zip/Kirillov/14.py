print("*".join(input()))
