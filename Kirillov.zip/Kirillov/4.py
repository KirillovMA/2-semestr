s = (input())
sum = 0
mult = 1
count = 0
count2 = 0
for i in range(len(s)):
    q=int(s[i])
    if q==55555:
       break
    if  i%2 != 1:
        sum += q
        count += 1
    else:
        mult *= q
        count2 += 1
print('Сумма чисел с нечетными номерами:', sum, 'Количество нечетных номеров:', count)
print('Произведение чисел с четными номерами:', mult, 'Количество четных номеров', count2)

